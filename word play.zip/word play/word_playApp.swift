//
//  word_playApp.swift
//  word play
//
//  Created by Student on 10/6/21.
//

import SwiftUI

@main
struct word_playApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
